package com.ntg.organization.organization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
